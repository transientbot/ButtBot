$.lang.register('discord.followhandler.usage', 'Usage: !followhandler [toggle / message / channel]');
$.lang.register('discord.followhandler.follow.toggle', 'Follow announcements have been $1.');
$.lang.register('discord.followhandler.follow.message.usage', 'Usage: !followhandler message [message] - Tag: (name)');
$.lang.register('discord.followhandler.follow.message.set', 'Follow announcements message set to: $1');
$.lang.register('discord.followhandler.follow.channel.usage', 'Usage: !followhandler channel [channel name]');
$.lang.register('discord.followhandler.follow.channel.set', 'Follow announcements will now be made in channel #$1');
