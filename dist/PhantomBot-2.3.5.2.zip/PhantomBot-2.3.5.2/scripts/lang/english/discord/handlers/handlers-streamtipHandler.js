$.lang.register('discord.streamtipshanlder.usage', 'Usage: !streamtiphandler [toggle / message / channel]');
$.lang.register('discord.streamtipshanlder.toggle', 'StreamTip donation announcements have been $1.');
$.lang.register('discord.streamtipshanlder.message.usage', 'Usage: !streamtiphandler message [message] - Tags: (name) (amount) (currency) (message)');
$.lang.register('discord.streamtipshanlder.message.set', 'StreamTip donation message set to: $1');
$.lang.register('discord.streamtipshanlder.channel.usage', 'Usage: !streamtiphandler channel [channel name]');
$.lang.register('discord.streamtipshanlder.channel.set', 'StreamTip donation will now be made in channel #$1');
